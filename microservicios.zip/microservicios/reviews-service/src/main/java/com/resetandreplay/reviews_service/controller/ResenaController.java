package com.resetandreplay.reviews_service.controller;

import com.resetandreplay.reviews_service.model.Resena;
import com.resetandreplay.reviews_service.repository.ResenaRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/resenas")
@Tag(name = "Reseñas", description = "Operaciones relacionadas con las reseñas de productos")
@CrossOrigin(origins = "http://localhost:5173")
public class ResenaController {

    @Autowired
    private ResenaRepository resenaRepository;

    // Endpoint para crear una nueva reseña
    // POST http://localhost:8084/resenas
    @PostMapping
    @Operation(summary = "Crear una nueva reseña", description = "Crea una nueva reseña para un producto.")
    @ApiResponse(responseCode = "201", description = "Reseña creada exitosamente")
    public ResponseEntity<Resena> createResena(@RequestBody Resena resena) {
        // Validar existencia previa por producto+usuario (única reseña por producto por usuario)
        Optional<Resena> existente = resenaRepository.findByIdProductoAndIdUsuario(resena.getIdProducto(), resena.getIdUsuario());
        if (existente.isPresent()) {
            // Ya existe una reseña; impedir crear duplicado
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
        resena.setFecha(LocalDateTime.now());
        Resena nuevaResena = resenaRepository.save(resena);
        return new ResponseEntity<>(nuevaResena, HttpStatus.CREATED);
    }

    // Endpoint para obtener todas las reseñas de un producto
    // GET http://localhost:8084/resenas/producto/1
    @GetMapping("/producto/{idProducto}")
    @Operation(summary = "Obtener reseñas por producto", description = "Obtiene todas las reseñas asociadas a un producto específico, ordenadas por fecha descendente.")
    @ApiResponse(responseCode = "200", description = "Lista de reseñas obtenida exitosamente")
    public ResponseEntity<List<Resena>> getResenasByProducto(@PathVariable int idProducto) {
        List<Resena> resenas = resenaRepository.findByIdProductoOrderByFechaDesc(idProducto);
        return ResponseEntity.ok(resenas);
    }

    // Obtener reseñas de un usuario
    // GET http://localhost:8084/resenas/usuario/{idUsuario}
    @GetMapping("/usuario/{idUsuario}")
    @Operation(summary = "Obtener reseñas por usuario", description = "Obtiene todas las reseñas escritas por un usuario.")
    public ResponseEntity<List<Resena>> getResenasByUsuario(@PathVariable int idUsuario) {
        List<Resena> resenas = resenaRepository.findByIdUsuario(idUsuario);
        return ResponseEntity.ok(resenas);
    }

    // Obtener reseña por producto+usuario (si existe)
    // GET http://localhost:8084/resenas/producto/{idProducto}/usuario/{idUsuario}
    @GetMapping("/producto/{idProducto}/usuario/{idUsuario}")
    @Operation(summary = "Obtener reseña por producto y usuario", description = "Obtiene la reseña que hizo un usuario a un producto, si existe.")
    public ResponseEntity<Resena> getResenaByProductoAndUsuario(@PathVariable int idProducto, @PathVariable int idUsuario) {
        Optional<Resena> resena = resenaRepository.findByIdProductoAndIdUsuario(idProducto, idUsuario);
        return resena.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // Actualizar reseña por id
    // PUT http://localhost:8084/resenas/{id}
    @PutMapping("/{id}")
    @Operation(summary = "Actualizar reseña", description = "Actualiza el texto y calificación de una reseña existente.")
    public ResponseEntity<Resena> updateResena(@PathVariable Long id, @RequestBody Resena resenaUpdate) {
        Optional<Resena> opt = resenaRepository.findById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Resena resena = opt.get();
        if (resenaUpdate.getTexto() != null) resena.setTexto(resenaUpdate.getTexto());
        if (resenaUpdate.getCalificacion() >= 1 && resenaUpdate.getCalificacion() <= 5) resena.setCalificacion(resenaUpdate.getCalificacion());
        resena.setFecha(LocalDateTime.now());
        Resena guardada = resenaRepository.save(resena);
        return ResponseEntity.ok(guardada);
    }

    // Eliminar reseña por id
    // DELETE http://localhost:8084/resenas/{id}
    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar reseña", description = "Elimina una reseña existente.")
    public ResponseEntity<Void> deleteResena(@PathVariable Long id) {
        if (!resenaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        resenaRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}