package com.resetandreplay.reviews_service.controller;

import com.resetandreplay.reviews_service.model.Contacto;
import com.resetandreplay.reviews_service.repository.ContactoRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/contactos")
@Tag(name = "Contacto", description = "Operaciones relacionadas con los mensajes de contacto")
@CrossOrigin(origins = "http://localhost:5173")
public class ContactoController {

    @Autowired
    private ContactoRepository contactoRepository;

    // POST http://localhost:8084/contactos
    @PostMapping
    @Operation(summary = "Crear un mensaje de contacto", description = "Guarda un nuevo mensaje de contacto enviado por un usuario")
    @ApiResponse(responseCode = "201", description = "Mensaje guardado exitosamente")
    public ResponseEntity<Contacto> createContacto(@RequestBody Contacto contacto) {
        contacto.setFechaCreacion(java.time.LocalDateTime.now());
        Contacto saved = contactoRepository.save(contacto);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    // GET http://localhost:8084/contactos
    @GetMapping
    @Operation(summary = "Obtener todos los mensajes de contacto", description = "Devuelve la lista de todos los mensajes de contacto recibidos")
    @ApiResponse(responseCode = "200", description = "Lista de mensajes obtenida exitosamente")
    public ResponseEntity<List<Contacto>> getAllContactos() {
        List<Contacto> contactos = contactoRepository.findAll();
        return ResponseEntity.ok(contactos);
    }

    // GET http://localhost:8084/contactos/{id}
    @GetMapping("/{id}")
    @Operation(summary = "Obtener un mensaje de contacto por ID", description = "Devuelve un mensaje específico según su ID")
    @ApiResponse(responseCode = "200", description = "Mensaje obtenido exitosamente")
    @ApiResponse(responseCode = "404", description = "Mensaje no encontrado")
    public ResponseEntity<Contacto> getContactoById(@PathVariable int id) {
        return contactoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE http://localhost:8084/contactos/{id}
    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un mensaje de contacto", description = "Elimina un mensaje de contacto existente")
    @ApiResponse(responseCode = "204", description = "Mensaje eliminado exitosamente")
    @ApiResponse(responseCode = "404", description = "Mensaje no encontrado")
    public ResponseEntity<Void> deleteContacto(@PathVariable int id) {
        if (!contactoRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        contactoRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
