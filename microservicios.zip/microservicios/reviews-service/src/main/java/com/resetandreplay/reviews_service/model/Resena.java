package com.resetandreplay.reviews_service.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "resenas")
public class Resena {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Guardamos los IDs de los otros servicios, no las entidades completas
    private int idProducto;
    private int idUsuario;

    private String texto;

    // Calificación de 1 a 5 estrellas
    private int calificacion;

    private LocalDateTime fecha;
}