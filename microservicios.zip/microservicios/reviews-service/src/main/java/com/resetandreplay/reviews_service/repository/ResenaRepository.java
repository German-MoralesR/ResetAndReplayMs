package com.resetandreplay.reviews_service.repository;

import com.resetandreplay.reviews_service.model.Resena;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ResenaRepository extends JpaRepository<Resena, Long> {

    // Busca todas las reseñas para un producto específico, ordenadas por fecha descendente
    List<Resena> findByIdProductoOrderByFechaDesc(int idProducto);

    // Busca todas las reseñas escritas por un usuario específico
    List<Resena> findByIdUsuario(int idUsuario);

    // Busca una reseña por producto y usuario (única)
    Optional<Resena> findByIdProductoAndIdUsuario(int idProducto, int idUsuario);
}