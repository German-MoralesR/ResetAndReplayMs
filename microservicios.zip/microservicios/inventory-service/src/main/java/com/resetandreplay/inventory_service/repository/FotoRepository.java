package com.resetandreplay.inventory_service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.resetandreplay.inventory_service.model.Foto_P; // Ajusta tu paquete

public interface FotoRepository extends JpaRepository<Foto_P, Integer> {
    @Query("SELECT f FROM Foto_P f WHERE f.producto.id_producto = :id_producto")
    List<Foto_P> findByProducto_id_producto(@Param("id_producto") int id_producto);
}