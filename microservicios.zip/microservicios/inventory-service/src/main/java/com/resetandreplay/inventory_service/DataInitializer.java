package com.resetandreplay.inventory_service;

import com.resetandreplay.inventory_service.model.Categoria;
import com.resetandreplay.inventory_service.model.Estado;
import com.resetandreplay.inventory_service.model.Plataforma;
import com.resetandreplay.inventory_service.repository.CategoriaRepository;
import com.resetandreplay.inventory_service.repository.EstadoRepository;
import com.resetandreplay.inventory_service.repository.PlataformaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Autowired
    private PlataformaRepository plataformaRepository;

    @Autowired
    private EstadoRepository estadoRepository;

    @Override
    public void run(String... args) throws Exception {
        // Sembrar Categorías
        if (categoriaRepository.count() == 0) {
            System.out.println("Sembrando categorías...");
            Categoria consolas = new Categoria();
            consolas.setNombre("Consolas");
            categoriaRepository.save(consolas);

            Categoria juegos = new Categoria();
            juegos.setNombre("Juegos");
            categoriaRepository.save(juegos);

            Categoria accesorios = new Categoria();
            accesorios.setNombre("Accesorios");
            categoriaRepository.save(accesorios);

            Categoria merchandising = new Categoria();
            merchandising.setNombre("Merchandising");
            categoriaRepository.save(merchandising);
        }

        // Sembrar Plataformas
        if (plataformaRepository.count() == 0) {
            System.out.println("Sembrando plataformas...");
            Plataforma snes = new Plataforma();
            snes.setNombre("SNES");
            plataformaRepository.save(snes);

            Plataforma n64 = new Plataforma();
            n64.setNombre("Nintendo 64");
            plataformaRepository.save(n64);

            Plataforma ps1 = new Plataforma();
            ps1.setNombre("PlayStation 1");
            plataformaRepository.save(ps1);
            
            Plataforma gbc = new Plataforma();
            gbc.setNombre("GameBoy Color");
            plataformaRepository.save(gbc);
        }

        // Sembrar Estados
        if (estadoRepository.count() == 0) {
            System.out.println("Sembrando estados...");
            Estado nuevo = new Estado();
            nuevo.setNombre("Nuevo");
            estadoRepository.save(nuevo);

            Estado usado = new Estado();
            usado.setNombre("Usado");
            estadoRepository.save(usado);

            Estado reacondicionado = new Estado();
            reacondicionado.setNombre("Reacondicionado");
            estadoRepository.save(reacondicionado);
        }

        System.out.println("Carga de datos iniciales completada.");
    }
}