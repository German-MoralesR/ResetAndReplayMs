package com.resetandreplay.inventory_service.controller;

import com.resetandreplay.inventory_service.model.Categoria;
import com.resetandreplay.inventory_service.repository.CategoriaRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/categorias")
@Tag(name = "Categoría", description = "Operaciones relacionadas con las categorías de inventario")
@CrossOrigin(origins = "http://localhost:5173")
public class CategoriaController {
    @Autowired
    private CategoriaRepository categoriaRepository;

    @GetMapping
    @Operation(summary = "Obtener todas las categorías", description = "Devuelve una lista de todas las categorías de inventario")
    @ApiResponse(responseCode = "200", description = "Lista de categorías obtenida exitosamente")
    public List<Categoria> getAllCategorias() {
        return categoriaRepository.findAll();
    }
}