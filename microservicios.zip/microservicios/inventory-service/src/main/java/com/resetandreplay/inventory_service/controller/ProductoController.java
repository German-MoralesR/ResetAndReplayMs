package com.resetandreplay.inventory_service.controller;

import com.resetandreplay.inventory_service.model.Categoria;
import com.resetandreplay.inventory_service.model.Estado;
import com.resetandreplay.inventory_service.model.Foto_P;
import com.resetandreplay.inventory_service.model.Plataforma;
import com.resetandreplay.inventory_service.model.Producto;
import com.resetandreplay.inventory_service.repository.ProductoRepository;
import com.resetandreplay.inventory_service.repository.CategoriaRepository;
import com.resetandreplay.inventory_service.repository.EstadoRepository;
import com.resetandreplay.inventory_service.repository.FotoRepository;
import com.resetandreplay.inventory_service.repository.PlataformaRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;
import java.util.Optional;
import java.io.IOException;
import java.util.List;  

@RestController
@RequestMapping("/productos") // Todas las URLs de este controlador empezarán con /productos
@Tag(name = "Producto", description = "Operaciones relacionadas con los productos de inventario")
@CrossOrigin(origins = "http://localhost:5173")
public class ProductoController {

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private FotoRepository fotoRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Autowired
    private EstadoRepository estadoRepository;

    @Autowired
    private PlataformaRepository plataformaRepository;

    // GET http://localhost:8082/productos
    @GetMapping
    @Operation(summary = "Obtener todos los productos", description = "Devuelve una lista con todos los productos")
    @ApiResponse(responseCode = "200", description = "Lista de productos obtenida exitosamente")
    public ResponseEntity<List<Producto>> getAllProductos() {
        List<Producto> productos = productoRepository.findAll();
        return ResponseEntity.ok(productos);
    }

    // GET http://localhost:8082/productos/1
    @GetMapping("/{id}")
    @Operation(summary = "Obtener un producto por ID", description = "Devuelve un producto específico según su ID")
    @ApiResponse(responseCode = "200", description = "Producto obtenido exitosamente")
    public ResponseEntity<Producto> getProductoById(@PathVariable int id) {
        return productoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/foto")
    @Operation(summary = "Obtener foto del producto", description = "Devuelve la primera foto almacenada del producto como recurso binario (image/*)")
    public ResponseEntity<byte[]> getProductoFoto(@PathVariable int id) {
        List<Foto_P> fotos = fotoRepository.findByProducto_id_producto(id);
        if (fotos == null || fotos.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Foto_P foto = fotos.get(0);
        byte[] data = foto.getFoto();
        String nombre = foto.getNombre() == null ? "" : foto.getNombre().toLowerCase();

        org.springframework.http.MediaType mediaType = org.springframework.http.MediaType.APPLICATION_OCTET_STREAM;
        if (nombre.endsWith(".png")) mediaType = org.springframework.http.MediaType.IMAGE_PNG;
        else if (nombre.endsWith(".jpg") || nombre.endsWith(".jpeg")) mediaType = org.springframework.http.MediaType.IMAGE_JPEG;
        else if (nombre.endsWith(".gif")) mediaType = org.springframework.http.MediaType.IMAGE_GIF;

        return ResponseEntity.ok()
                .contentType(mediaType)
                .body(data);
    }

    // POST http://localhost:8082/productos
    @PostMapping(consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    @Operation(summary = "Crear producto con foto", description = "Crea producto y guarda su foto en tabla separada")
    public ResponseEntity<Producto> createProducto(
            @RequestPart("producto") Producto producto,
            @RequestPart(value = "file", required = false) MultipartFile file
    ) {
        try {
            // 1. Guardamos el producto PRIMERO para generar su ID
            Producto nuevoProducto = productoRepository.save(producto);

            // 2. Si el usuario subió una imagen, la guardamos en la tabla Foto_P
            if (file != null && !file.isEmpty()) {
                Foto_P nuevaFoto = new Foto_P();
                nuevaFoto.setNombre(file.getOriginalFilename()); // Guardamos el nombre original
                nuevaFoto.setFoto(file.getBytes()); // Guardamos los bytes de la imagen
                nuevaFoto.setProducto(nuevoProducto); // <--- VINCULACIÓN IMPORTANTE
                
                fotoRepository.save(nuevaFoto); // Guardamos en la tabla foto_p
            }

            return new ResponseEntity<>(nuevoProducto, HttpStatus.CREATED);

        } catch (IOException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // PUT http://localhost:8082/productos/1 (Actualizar con foto)
    @PutMapping(value = "/{id}", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    @Operation(summary = "Actualizar un producto con foto", description = "Actualiza un producto existente y su foto")
    public ResponseEntity<Producto> updateProductoConFoto(
            @PathVariable int id,
            @RequestPart("producto") Producto productoActualizado,
            @RequestPart(value = "file", required = false) MultipartFile file
    ) {
        try {
            Optional<Producto> productoOptional = productoRepository.findById(id);

            if (productoOptional.isEmpty()) {
                return ResponseEntity.notFound().build();
            }

            Producto producto = productoOptional.get();

            // Actualizar campos básicos
            if (productoActualizado.getNombre() != null) {
                producto.setNombre(productoActualizado.getNombre());
            }
            if (productoActualizado.getDescripcion() != null) {
                producto.setDescripcion(productoActualizado.getDescripcion());
            }
            if (productoActualizado.getPrecio() > 0) {
                producto.setPrecio(productoActualizado.getPrecio());
            }
            if (productoActualizado.getStock() >= 0) {
                producto.setStock(productoActualizado.getStock());
            }
            if (productoActualizado.getSku() != null) {
                producto.setSku(productoActualizado.getSku());
            }

            // Actualizar relaciones
            if (productoActualizado.getCategoria() != null && productoActualizado.getCategoria().getId_cat() > 0) {
                Categoria categoria = categoriaRepository.findById(productoActualizado.getCategoria().getId_cat()).orElse(null);
                producto.setCategoria(categoria);
            }
            if (productoActualizado.getEstado() != null && productoActualizado.getEstado().getId_estado() > 0) {
                Estado estado = estadoRepository.findById(productoActualizado.getEstado().getId_estado()).orElse(null);
                producto.setEstado(estado);
            }
            if (productoActualizado.getPlataforma() != null && productoActualizado.getPlataforma().getId_plat() > 0) {
                Plataforma plataforma = plataformaRepository.findById(productoActualizado.getPlataforma().getId_plat()).orElse(null);
                producto.setPlataforma(plataforma);
            }

            // Guardar el producto primero
            Producto productoGuardado = productoRepository.save(producto);

            // Si hay una nueva foto, eliminar la antigua y guardar la nueva
            if (file != null && !file.isEmpty()) {
                // Eliminar foto anterior si existe
                List<Foto_P> fotosAnteriores = fotoRepository.findByProducto_id_producto(id);
                if (!fotosAnteriores.isEmpty()) {
                    fotoRepository.deleteAll(fotosAnteriores);
                }

                // Guardar nueva foto
                Foto_P nuevaFoto = new Foto_P();
                nuevaFoto.setNombre(file.getOriginalFilename());
                nuevaFoto.setFoto(file.getBytes());
                nuevaFoto.setProducto(productoGuardado);
                fotoRepository.save(nuevaFoto);
            }

            return ResponseEntity.ok(productoGuardado);

        } catch (IOException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // PUT http://localhost:8082/productos/{id}/stock
    @PutMapping("/{id}/stock")
    @Operation(summary = "Reducir stock de un producto", description = "Reduce el stock disponible de un producto por una cantidad especificada.")
    @ApiResponse(responseCode = "200", description = "Stock actualizado exitosamente")
    @ApiResponse(responseCode = "400", description = "Stock insuficiente")
    @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    public ResponseEntity<Map<String, String>> reduceStock(
            @PathVariable int id,
            @RequestBody Map<String, Integer> request
    ) {
        Integer cantidad = request.get("cantidad");
        
        if (cantidad == null || cantidad <= 0) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "La cantidad debe ser mayor a 0"));
        }

        Optional<Producto> productoOpt = productoRepository.findById(id);
        if (productoOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Producto producto = productoOpt.get();
        if (producto.getStock() < cantidad) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Stock insuficiente. Disponible: " + producto.getStock()));
        }

        producto.setStock(producto.getStock() - cantidad);
        productoRepository.save(producto);

        return ResponseEntity.ok(Map.of("mensaje", "Stock actualizado", "nuevoStock", String.valueOf(producto.getStock())));
    }

    // DELETE http://localhost:8082/productos/1
    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un producto", description = "Elimina un producto específico según su ID")
    @ApiResponse(responseCode = "204", description = "Producto eliminado exitosamente")
    public ResponseEntity<Void> deleteProducto(@PathVariable int id) {
        if (!productoRepository.existsById(id)) {
            return ResponseEntity.notFound().build(); // Devuelve 404 si no existe
        }
        productoRepository.deleteById(id);
        return ResponseEntity.noContent().build(); // Devuelve 204 No Content si fue exitoso
    }
}
