package com.resetandreplay.inventory_service.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Foto_P {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_fo;
    
    private String nombre; // Nombre del archivo (ej: "mario.jpg")

    // CAMBIO IMPORTANTE: De String a byte[]
    @Lob 
    @Column(columnDefinition = "LONGBLOB") 
    private byte[] foto; 

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_producto")
    @JsonIgnore 
    private Producto producto;
}