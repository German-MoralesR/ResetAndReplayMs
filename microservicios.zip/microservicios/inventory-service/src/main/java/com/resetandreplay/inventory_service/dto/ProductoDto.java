package com.resetandreplay.inventory_service.dto;

import lombok.Data;

@Data
public class ProductoDto {
    private int id_producto;
    private String nombre;
}