package com.resetandreplay.inventory_service.repository;

import com.resetandreplay.inventory_service.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Integer> {
    // JpaRepository ya nos da findAll(), findById(), save(), deleteById(), etc.
}