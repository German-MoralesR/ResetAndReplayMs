package com.resetandreplay.inventory_service.controller;

import com.resetandreplay.inventory_service.model.Plataforma;
import com.resetandreplay.inventory_service.repository.PlataformaRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/plataformas")
@Tag(name = "Plataforma", description = "Operaciones relacionadas con las plataformas de inventario")
@CrossOrigin(origins = "http://localhost:5173")
public class PlataformaController {
    @Autowired
    private PlataformaRepository plataformaRepository;

    @GetMapping
    @Operation(summary = "Obtener todas las plataformas", description = "Devuelve una lista de todas las plataformas de inventario")
    @ApiResponse(responseCode = "200", description = "Lista de plataformas obtenida exitosamente")
    public List<Plataforma> getAllPlataformas() {
        return plataformaRepository.findAll();
    }
}