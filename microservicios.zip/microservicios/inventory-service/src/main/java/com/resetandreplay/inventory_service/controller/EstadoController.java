package com.resetandreplay.inventory_service.controller;

import com.resetandreplay.inventory_service.model.Estado;
import com.resetandreplay.inventory_service.repository.EstadoRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/estados")
@Tag(name = "Estado", description = "Operaciones relacionadas con los estados de inventario")
@CrossOrigin(origins = "http://localhost:5173")
public class EstadoController {
    @Autowired
    private EstadoRepository estadoRepository;

    @GetMapping
    @Operation(summary = "Obtener todos los estados", description = "Devuelve una lista de todos los estados de inventario")
    @ApiResponse(responseCode = "200", description = "Lista de estados obtenida exitosamente")
    public List<Estado> getAllEstados() {
        return estadoRepository.findAll();
    }
}
