package com.resetandreplay.inventory_service.model;

import lombok.Data;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
@Data
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_producto;
    private String nombre;
    private String descripcion;
    private double precio;
    private int stock;
    private String sku;

    // --- Relaciones ManyToOne (Muchos productos pueden tener una misma categoría, etc.) ---
    @ManyToOne
    @JoinColumn(name = "id_cat")
    private Categoria categoria;

    @ManyToOne
    @JoinColumn(name = "id_plat")
    private Plataforma plataforma;

    @ManyToOne
    @JoinColumn(name = "id_estado")
    private Estado estado;

    // --- Relación OneToMany (Un producto puede tener muchas fotos) ---
    @OneToMany(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Foto_P> fotos;

}