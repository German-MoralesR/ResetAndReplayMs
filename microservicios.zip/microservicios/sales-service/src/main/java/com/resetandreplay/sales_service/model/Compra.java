package com.resetandreplay.sales_service.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@Table(name = "compras")
public class Compra {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_compra;

    @Column(name = "id_usuario")
    private int idUsuario; // Guardamos solo el ID del usuario
    private LocalDateTime fecha;
    private double total;

    @OneToMany(mappedBy = "compra", cascade = CascadeType.ALL)
    private List<Detalle> detalles;
}