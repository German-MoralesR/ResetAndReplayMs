package com.resetandreplay.sales_service.dto;

import lombok.Data;

@Data
public class ProductoDto {
    private int id_producto;
    private String nombre;
    // No necesitas más campos, solo el nombre para el mensaje de error.
}