package com.resetandreplay.sales_service.dto;

import lombok.Data;
import java.util.List;

@Data
public class CompraDto {
    private int id_usuario;
    private List<DetalleDto> detalles;
}