package com.resetandreplay.sales_service.controller;

import com.resetandreplay.sales_service.dto.CompraDto;
import com.resetandreplay.sales_service.dto.DetalleDto;
import com.resetandreplay.sales_service.dto.ProductoDto;
import com.resetandreplay.sales_service.model.Compra;
import com.resetandreplay.sales_service.model.Detalle;
import com.resetandreplay.sales_service.repository.CompraRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/compras")
@Tag(name = "Compra Controller", description = "Endpoints para gestionar compras")
@CrossOrigin(origins = "http://localhost:5173")
public class CompraController {

    @Autowired
    private CompraRepository compraRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    // Endpoint para obtener el historial de compras de un usuario
    @GetMapping("/usuario/{idUsuario}")
    @Operation(summary = "Obtener historial de compras por usuario", description = "Devuelve todas las compras realizadas por un usuario específico.")
    @ApiResponse(responseCode = "200", description = "Lista de compras obtenida exitosamente")
    public ResponseEntity<List<Compra>> getComprasByUsuario(@PathVariable int idUsuario) {
        List<Compra> compras = compraRepository.findByIdUsuario(idUsuario);
        // Devuelve la lista, que puede estar vacía, pero siempre con un 200 OK.
        return ResponseEntity.ok(compras);
    }

    // Endpoint para crear una nueva compra
    @PostMapping
    @Transactional // La transacción es sobre la BD de ventas, no sobre el stock
    @Operation(summary = "Crear una nueva compra", description = "Registra una nueva compra y actualiza el stock de los productos correspondientes.")
    @ApiResponse(responseCode = "201", description = "Compra creada exitosamente")
    public ResponseEntity<Map<String, String>> createCompra(@RequestBody CompraDto compraDto) {

        // --- NUEVA FASE 0: OBTENER DATOS DE LOS PRODUCTOS ---
        // Extraemos todos los IDs de producto del carrito.
        List<Integer> productIds = compraDto.getDetalles().stream()
                                        .map(DetalleDto::getId_producto)
                                        .toList();

        // Hacemos una llamada al inventory-service para obtener los detalles de estos productos.
        // Usamos WebClient para hacer una petición GET a /productos y filtrar por IDs.
        // NOTA: Un endpoint dedicado /productos/by-ids sería más eficiente, pero esto funciona.
        List<ProductoDto> productosDelCarrito;
        try {
            productosDelCarrito = webClientBuilder.build()
                .get()
                .uri("http://localhost:8082/productos") // Obtenemos TODOS los productos
                .retrieve()
                .bodyToFlux(ProductoDto.class) // Los recibimos como un flujo de DTOs
                .collectList() // Los convertimos a una lista
                .block() // Esperamos la respuesta
                .stream()
                .filter(p -> productIds.contains(p.getId_producto())) // Filtramos para quedarnos solo con los de nuestro carrito
                .toList();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                .body(Map.of("error", "No se pudo comunicar con el servicio de inventario."));
        }
        

        // --- FASE 1: INTENTAR REDUCIR STOCK ---
        List<DetalleDto> detallesProcesados = new ArrayList<>();
        String errorMensaje = null;

        for (DetalleDto detalleDto : compraDto.getDetalles()) {
            try {
                webClientBuilder.build()
                    .put()
                    .uri("http://localhost:8082/productos/" + detalleDto.getId_producto() + "/stock")
                    .bodyValue(Map.of("cantidad", detalleDto.getCantidad()))
                    .retrieve()
                    .onStatus(HttpStatus.CONFLICT::equals, response -> {
                        // --- ¡AQUÍ ESTÁ EL CAMBIO! ---
                        // Buscamos el nombre del producto que falló en la lista que obtuvimos antes.
                        String nombreProducto = productosDelCarrito.stream()
                            .filter(p -> p.getId_producto() == detalleDto.getId_producto())
                            .findFirst()
                            .map(ProductoDto::getNombre)
                            .orElse("ID: " + detalleDto.getId_producto()); // Fallback por si no lo encontramos
                        
                        return Mono.error(new RuntimeException("Stock insuficiente para el producto: '" + nombreProducto + "'"));
                    })
                    .toBodilessEntity()
                    .block();

                detallesProcesados.add(detalleDto);

            } catch (Exception e) {
                errorMensaje = e.getMessage();
                break;
            }
        }

        // --- FASE 2: COMPENSAR SI HUBO ERROR ---
        if (errorMensaje != null) {
            for (DetalleDto detalleCompensar : detallesProcesados) {
                webClientBuilder.build()
                    .put()
                    .uri("http://localhost:8082/productos/" + detalleCompensar.getId_producto() + "/stock")
                    .bodyValue(Map.of("cantidad", -detalleCompensar.getCantidad()))
                    .retrieve()
                    .toBodilessEntity()
                    .block();
            }
            
            Map<String, String> errorBody = Map.of("error", errorMensaje);
            return ResponseEntity.status(HttpStatus.CONFLICT).body(errorBody);
        }

        // --- FASE 3: GUARDAR LA COMPRA (sin cambios) ---
        Compra compra = new Compra();
        compra.setIdUsuario(compraDto.getId_usuario());
        // ... resto del código para guardar la compra ...
        compra.setFecha(LocalDateTime.now());

        List<Detalle> detalles = new ArrayList<>();
        double totalCompra = 0;

        for (DetalleDto dto : compraDto.getDetalles()) {
            Detalle detalle = new Detalle();
            detalle.setId_producto(dto.getId_producto());
            detalle.setCantidad(dto.getCantidad());
            detalle.setPrecio(dto.getPrecio());
            detalle.setSubtotal(dto.getCantidad() * dto.getPrecio());
            detalle.setCompra(compra);
            detalles.add(detalle);
            totalCompra += detalle.getSubtotal();
        }

        compra.setDetalles(detalles);
        compra.setTotal(totalCompra);
        compraRepository.save(compra);

        Map<String, String> responseBody = Map.of("mensaje", "Compra realizada con éxito");
        return new ResponseEntity<>(responseBody, HttpStatus.CREATED);
    }
}