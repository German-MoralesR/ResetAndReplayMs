package com.resetandreplay.sales_service.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "detalles")
public class Detalle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_detalle;

    private int id_producto; // Guardamos solo el ID del producto
    private int cantidad;
    private double precio; // Precio del producto en el momento de la compra
    private double subtotal;

    @ManyToOne
    @JoinColumn(name = "id_compra")
    @JsonIgnore
    private Compra compra;
}