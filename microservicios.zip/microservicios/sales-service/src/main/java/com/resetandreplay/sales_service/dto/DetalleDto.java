package com.resetandreplay.sales_service.dto;

import lombok.Data;

@Data
public class DetalleDto {
    private int id_producto;
    private int cantidad;
    private double precio; // Precio unitario en el momento de la compra
}
