package com.resetandreplay.sales_service.repository;

import com.resetandreplay.sales_service.model.Compra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CompraRepository extends JpaRepository<Compra, Integer> {
    // Método para buscar todas las compras de un usuario
    List<Compra> findByIdUsuario(int idUsuario);
}