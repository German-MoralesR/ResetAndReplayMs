package com.resetandreplay.user_service.repository;

import com.resetandreplay.user_service.model.Usuario;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
    // Podemos añadir métodos personalizados. Spring Data JPA infiere la consulta por el nombre.
    // Por ejemplo, para buscar un usuario por su correo:
    //Usuario findByCorreo(String correo);
    // Spring Data JPA infiere la consulta por el nombre del método
    Optional<Usuario> findByCorreo(String correo);
}