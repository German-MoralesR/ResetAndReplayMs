package com.resetandreplay.user_service.controller;

import com.resetandreplay.user_service.dto.LoginDto;
import com.resetandreplay.user_service.dto.ResetPasswordDto;
import com.resetandreplay.user_service.model.Rol;
import com.resetandreplay.user_service.model.Usuario;
import com.resetandreplay.user_service.repository.UsuarioRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // Indica que esta clase es un controlador REST
@RequestMapping("/usuarios") // Todas las URLs de este controlador empezarán con /usuarios
@Tag(name = "Usuario Controller", description = "Endpoints para gestionar usuarios")
@CrossOrigin(origins = "http://localhost:5173") // Permite solicitudes desde el frontend en desarrollo
public class UsuarioController {

    @Autowired // Spring inyecta una instancia de UsuarioRepository automáticamente
    private UsuarioRepository usuarioRepository;

    // Endpoint para obtener todos los usuarios
    // GET http://localhost:8081/usuarios
    @GetMapping
    @Operation(summary = "Obtener todos los usuarios", description = "Devuelve una lista con todos los usuarios registrados")
    @ApiResponse(responseCode = "200", description = "Lista de usuarios obtenida correctamente")
    public List<Usuario> getAll() {
        return usuarioRepository.findAll();
    }

    // Endpoint para obtener un usuario por ID
    // GET http://localhost:8081/usuarios/1
    @GetMapping("/{id}")
    @Operation(summary = "Obtener usuario por ID", description = "Devuelve un usuario específico según su ID")
    @ApiResponse(responseCode = "200", description = "Usuario obtenido correctamente")
    public ResponseEntity<Usuario> getById(@PathVariable("id") int id) {
        return usuarioRepository.findById(id)
                .map(ResponseEntity::ok) // Si lo encuentra, devuelve 200 OK con el usuario
                .orElse(ResponseEntity.notFound().build()); // Si no, devuelve 404 Not Found
    }

    // Endpoint para crear un nuevo usuario
    // POST http://localhost:8081/usuarios
    // El cuerpo de la petición debe ser un JSON con los datos del usuario
    @PostMapping("/login")
    @Operation(summary = "Login de usuario", description = "Permite a un usuario iniciar sesión con su correo y contraseña")
    @ApiResponse(responseCode = "200", description = "Login exitoso")
    public ResponseEntity<Usuario> login(@RequestBody LoginDto loginDto) {
        // Busca al usuario por su correo
        Usuario usuario = usuarioRepository.findByCorreo(loginDto.getCorreo()).orElse(null);

        // Si el usuario no existe o la contraseña no coincide
        if (usuario == null || !usuario.getPassword().equals(loginDto.getPassword())) {
            // Devolvemos un error 401 Unauthorized
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        // Si todo está bien, devolvemos el usuario con un 200 OK
        return ResponseEntity.ok(usuario);
    }

    // Método para crear un nuevo usuario (POST /usuarios)
    @PostMapping
    @Operation(summary = "Crear nuevo usuario", description = "Permite registrar un nuevo usuario en el sistema")
    @ApiResponse(responseCode = "201", description = "Usuario creado correctamente")
    public ResponseEntity<Usuario> create(@RequestBody Usuario usuario) {
        // 1. Verificar si ya existe un usuario con ese correo
        if (usuarioRepository.findByCorreo(usuario.getCorreo()).isPresent()) {
            // Si existe, devolvemos un 409 Conflict
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }

        // 2. Asignar un rol por defecto si no se especifica uno
        // Suponiendo que el ID del rol de usuario normal es 2
        if (usuario.getRol() == null) {
            Rol rolUsuario = new Rol();
            rolUsuario.setId_rol(2); // ¡Asegúrate de que el ID 2 corresponde al rol de usuario en tu BD!
            usuario.setRol(rolUsuario);
        }
        
        // 3. Guardar el nuevo usuario y devolverlo con un 201 Created
        Usuario nuevoUsuario = usuarioRepository.save(usuario);
        return new ResponseEntity<>(nuevoUsuario, HttpStatus.CREATED);
    }

    @PutMapping("/reset-password")
    @Operation(summary = "Restablecer contraseña", description = "Permite a un usuario restablecer su contraseña mediante su correo electrónico")
    @ApiResponse(responseCode = "200", description = "Contraseña restablecida correctamente")
    public ResponseEntity<Void> resetPassword(@RequestBody ResetPasswordDto resetDto) {
        // Buscamos al usuario por su correo
        return usuarioRepository.findByCorreo(resetDto.getCorreo()).map(usuario -> {
            // Si lo encontramos, actualizamos su contraseña
            usuario.setPassword(resetDto.getNewPassword());
            usuarioRepository.save(usuario);
            // Devolvemos 200 OK sin cuerpo
            return ResponseEntity.ok().<Void>build();
        }).orElse(ResponseEntity.notFound().build()); // Si no lo encontramos, devolvemos 404
    }

    // Endpoint para obtener un usuario por EMAIL
    // GET http://localhost:8081/usuarios/email/alguien@example.com
    @GetMapping("/email/{correo}")
    @Operation(summary = "Obtener usuario por correo electrónico", description = "Devuelve un usuario específico según su correo electrónico")
    @ApiResponse(responseCode = "200", description = "Usuario obtenido correctamente")  
    public ResponseEntity<Usuario> getByEmail(@PathVariable("correo") String correo) {
        return usuarioRepository.findByCorreo(correo)
                .map(ResponseEntity::ok) // Si lo encuentra, devuelve 200 OK
                .orElse(ResponseEntity.notFound().build()); // Si no, 404 Not Found
    }
}
