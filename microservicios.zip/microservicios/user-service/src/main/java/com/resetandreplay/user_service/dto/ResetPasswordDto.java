package com.resetandreplay.user_service.dto;

import lombok.Data;

@Data
public class ResetPasswordDto {
    private String correo;
    private String newPassword;
}