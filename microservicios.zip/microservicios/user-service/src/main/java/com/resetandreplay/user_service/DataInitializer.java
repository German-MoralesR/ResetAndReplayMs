package com.resetandreplay.user_service;

import com.resetandreplay.user_service.model.Usuario;
import com.resetandreplay.user_service.repository.UsuarioRepository;
import com.resetandreplay.user_service.model.Rol;
import com.resetandreplay.user_service.repository.RolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private RolRepository rolRepository;

    @Autowired
    private UsuarioRepository usuarioRepository; // <-- 3. Inyectar el repositorio

    @Override
    public void run(String... args) throws Exception {
        // --- SEMBRAR ROLES ---
        if (rolRepository.count() == 0) {
            System.out.println("Sembrando roles en la base de datos...");

            rolRepository.saveAll(List.of(
                new Rol(1, "ADMIN"),   // ID 1 para ADMIN
                new Rol(2, "USUARIO") // ID 2 para USUARIO
            ));

            System.out.println("Roles sembrados exitosamente.");
        } else {
            System.out.println("La tabla de roles ya contiene datos. No se necesita sembrar.");
        }

        // --- 4. SEMBRAR USUARIOS ---
        if (usuarioRepository.count() == 0) {
            System.out.println("Sembrando usuarios de prueba...");

            // Buscamos los roles que acabamos de crear (o que ya existían)
            Rol rolAdmin = rolRepository.findById(1).orElseThrow(() -> new RuntimeException("Error: Rol ADMIN no encontrado"));
            Rol rolUsuario = rolRepository.findById(2).orElseThrow(() -> new RuntimeException("Error: Rol USUARIO no encontrado"));

            // Crear usuario Administrador
            Usuario admin = new Usuario();
            admin.setNombre("Administrador");
            admin.setCorreo("admin@gmail.com");
            admin.setPassword("Admin123!"); // En un proyecto real, esto debería estar encriptado
            admin.setTelefono("987654321"); // Teléfono de ejemplo
            admin.setFoto_perfil("");
            admin.setRol(rolAdmin);

            // Crear usuario Común
            Usuario user = new Usuario();
            user.setNombre("Usuario de Prueba");
            user.setCorreo("user@gmail.com");
            user.setPassword("User123!");
            user.setTelefono("123456789"); // Teléfono de ejemplo
            user.setFoto_perfil("");
            user.setRol(rolUsuario);

            // Guardamos la lista de usuarios en la base de datos
            usuarioRepository.saveAll(List.of(admin, user));

            System.out.println("Usuarios de prueba sembrados exitosamente.");
        } else {
            System.out.println("La tabla de usuarios ya contiene datos. No se necesita sembrar.");
        }
    }
}