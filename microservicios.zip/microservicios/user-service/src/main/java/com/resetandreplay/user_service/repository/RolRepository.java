package com.resetandreplay.user_service.repository;

import com.resetandreplay.user_service.model.Rol;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository // Marca esto como un componente de repositorio de Spring
public interface RolRepository extends JpaRepository<Rol, Integer> {
    // JpaRepository ya nos da métodos como findAll(), findById(), save(), delete()
}
