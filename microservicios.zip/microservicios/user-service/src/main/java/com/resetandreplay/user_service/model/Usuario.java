package com.resetandreplay.user_service.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "Usuario") // Especifica el nombre de la tabla en la BD
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_usuario;

    private String nombre;
    private String correo;
    private String telefono;
    private String foto_perfil; // Guardaremos la URL o la ruta a la imagen
    private String password;

    // --- Relación con Rol ---
    // Muchos usuarios pueden tener un rol.
    @ManyToOne(fetch = FetchType.EAGER) // EAGER carga el rol junto con el usuario
    @JoinColumn(name = "id_rol") // La columna en la tabla 'Usuario' que es la clave foránea
    private Rol rol;
}
