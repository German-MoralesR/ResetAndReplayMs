package com.resetandreplay.user_service.dto;

import lombok.Data;

@Data
public class LoginDto {
    private String correo;
    private String password;
}